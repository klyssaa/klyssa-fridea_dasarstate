package com.example.master_plan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
